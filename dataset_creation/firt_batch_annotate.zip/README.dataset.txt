# My First Project > 2025-08-25 6:34pm
https://universe.roboflow.com/bolt-csiwm/my-first-project-otzcm

Provided by a Roboflow user
License: CC BY 4.0

